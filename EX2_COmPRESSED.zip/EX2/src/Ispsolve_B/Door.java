package Ispsolve_B;

public class Door {
    void lock(){}
    void unlock(){}
}