package Ispsolve_B;

public interface PasswordClient {
    void alarm();
    void setMyProtector(PasswordProtector protector);
}