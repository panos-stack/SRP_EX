package Ispsolve_A;

public class Door {
    public void lock(){}

    public void unlock(){}
}
