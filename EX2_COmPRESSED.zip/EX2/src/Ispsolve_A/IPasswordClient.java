package Ispsolve_A;

public interface IPasswordClient {
    void alarm();
    void setMyProtector(PasswordProtector protector);
}
