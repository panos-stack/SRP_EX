package Srpsolve_B;

import java.security.spec.RSAOtherPrimeInfo;

public class Main {
    public static void main(String[] args){
        System.out.println("Hello");
    }
}
