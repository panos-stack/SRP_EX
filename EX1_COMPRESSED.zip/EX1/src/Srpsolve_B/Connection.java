package Srpsolve_B;

public interface Connection {
    void dial(String pno);
    void hangup();
}