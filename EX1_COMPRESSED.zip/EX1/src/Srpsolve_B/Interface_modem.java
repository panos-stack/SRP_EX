package Srpsolve_B;

public interface Interface_modem {
    void dial(String pno);
    void hangup();
    void send(char c);
    char recv();
}