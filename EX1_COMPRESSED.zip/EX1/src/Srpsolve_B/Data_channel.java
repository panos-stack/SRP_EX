package Srpsolve_B;

public interface Data_channel {
    void send(char c);
    char recv();
}